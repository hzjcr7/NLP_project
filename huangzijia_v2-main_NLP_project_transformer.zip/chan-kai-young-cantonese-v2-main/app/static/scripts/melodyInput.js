const OCTAVE_PLACEHOLDER = {
    label: "八度 4 Octave 4",
    value: "4",
}
const MAX_MELODY_LENGTH = 12

document.addEventListener("alpine:init", () => {
    Alpine.data("melodyInput", () => ({
        melody: ["E5", "Cs5", "B4", "D5", "Cs5", "B4", "A4"], // []
        selectedOctave: OCTAVE_PLACEHOLDER,
        showErrorToast (msg) {
            Toastify({
                text: msg,
                duration: 3500,
                close: false,
                gravity: "bottom",
                position: "right",
                stopOnFocus: true,
                className: "p-6 rounded-md",
                style: {
                    background: "radial-gradient(circle at 81.9% 53.5%, rgb(173, 53, 53) 16.3%, rgb(240, 60, 60) 100.2%)"
                }
              }).showToast();
        },
        isLoading: false,
        noteToPitch (note) {
            const pitch = note + this.selectedOctave.value;
            return pitch.replace("#", "s");
        },
        addNoteHandler (event) {
            if (this.melody.length >= MAX_MELODY_LENGTH) {
                this.showErrorToast("旋律長度不可超過 12 音符 Melody length cannot exceed 12 notes.")
                return
            }
            const pitch = this.noteToPitch(event.detail.note);
            this.melody.push(pitch)
        },
        removeNoteHandler () {
            this.melody.pop()
        },
        clearMelodyHandler () {
            this.melody = []
        },
        octaveInputHandler (octave) {
            this.selectedOctave = octave;
        },                  
                    
        handleTonesGeneratorFormSubmit () {
            this.isLoading = true

            htmx.ajax(
                "POST",
                "/get-tones",
                {
                    target: document.querySelector("#generated-tones"),
                    swap: "innerHTML",
                    values: {
                        melody_input: this.melody,
                    },
                    handler: (body, ctx) => {
                        const statusCode = ctx.xhr.status
                        if (statusCode === 200) {
                            htmx.swap("#generated-tones", ctx.xhr.response, { swapStyle: "innerHTML" })
                        } else if (statusCode === 500) {
                            const errorMsg = JSON.parse(ctx.xhr.response).message
                            this.showErrorToast("伺服器錯誤 Server error: " + errorMsg)
                        }
                        this.isLoading = false
                    }
                }
            )
        }
    }))
})