const playMelodyHandler = (melody) => {
    const melody_without_arrows = melody.melody_without_arrows
    const synth = new Tone.Synth().toDestination()
    const delay = Tone.now()
    melody_without_arrows.map((pitch, ind) => {
        synth.triggerAttackRelease(pitch, "8n", delay + 0.5 * ind)
    })
}

const shuffleMelodiesHandler = () => {
    const melodyScores = document.querySelectorAll('#melody-score');
    const numResultText = document.querySelector('#num-results');
    numResultText.innerHTML = `共有${melodyScores.length}項結果，隨機抽選10項`;

    const numResultTextEng = document.querySelector('#num-results-en');
    numResultTextEng.innerHTML = `10 of ${melodyScores.length} possibilities`;
    
    // reset the hidden class for all melody scores
    melodyScores.forEach(scores => {
        scores.classList.remove('hidden');
    });
    
    const shuffledScores = Array.from(melodyScores).sort(() => Math.random() - 0.5);
    const remainingScores = shuffledScores.slice(10);
    
    remainingScores.forEach(scores => {
        scores.classList.add('hidden');
    });
}

const showAllMelodiesHandler = () => {
    const melodyScores = document.querySelectorAll('#melody-score');
    const numResultText = document.querySelector('#num-results');
    numResultText.innerHTML = `共有${melodyScores.length}項結果`;

    const numResultTextEng = document.querySelector('#num-results-en');
    numResultTextEng.innerHTML = `Number of possibilities: ${melodyScores.length}`;

    melodyScores.forEach(scores => {
        scores.classList.remove('hidden');
    });
}