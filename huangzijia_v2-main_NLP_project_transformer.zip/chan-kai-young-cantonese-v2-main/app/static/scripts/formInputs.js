const RANGE_OPTIONS = [
    {
        label: "音域不限 Unlimited Range",
        value: "no_filter"
    },
    {
        label: "≤八度⠀⠀⠀⠀⠀≤ octave",
        value: "12"
    },
    {
        label: "≤八度加五度⠀≤ octave + 5th",
        value: "19"
    },
    {
        label: "≤兩個八度⠀⠀≤ 2 octaves",
        value: "24"
    },
]
FIRST_PITCH_PLACEHOLDER = "起音 1st pitch"

document.addEventListener("alpine:init", () => {
    Alpine.data("getMelodyGeneratorFormData", () => ({
        melodyGeneratorFormData: {
            phrase: undefined,
            first_pitch: FIRST_PITCH_PLACEHOLDER,
            octave_range: {
                label: "音域範圍 Range",
                value: undefined
            },
        },
        showErrorToast (msg) {
            Toastify({
                text: msg,
                duration: 3500,
                close: false,
                gravity: "bottom",
                position: "right",
                stopOnFocus: true,
                className: "p-6 rounded-md",
                style: {
                    background: "radial-gradient(circle at 81.9% 53.5%, rgb(173, 53, 53) 16.3%, rgb(240, 60, 60) 100.2%)"
                }
              }).showToast();
        },
        isLoading: false,
        setPitch (pitch) {
            this.melodyGeneratorFormData.first_pitch = pitch
        },
        setRange (range) {
            this.melodyGeneratorFormData.octave_range = range
        },
        handleMelodyGeneratorFormSubmit () {
            this.isLoading = true

            // form validation
            const { phrase, first_pitch, octave_range } = this.melodyGeneratorFormData
            if (!phrase) {
                this.showErrorToast("請輸入句子 Please enter a phrase.")
                this.isLoading = false
                return
            }
            else if (first_pitch === FIRST_PITCH_PLACEHOLDER) {
                this.showErrorToast("請選擇起音 Please select a starting pitch.")
                this.isLoading = false
                return
            }
            else if (!octave_range.value) {
                this.showErrorToast("請選擇音域 Please select a range.")
                this.isLoading = false
                return
            }
            
            htmx.ajax(
                "POST",
                "/get-melodies",
                {
                    values: {
                        ...this.melodyGeneratorFormData,
                        octave_range: octave_range.value
                    },
                    handler: (body, ctx) => {
                        const statusCode = ctx.xhr.status
                        if (statusCode === 200) {
                            htmx.swap("#generated-melodies", ctx.xhr.response, { swapStyle: "innerHTML" })
                        } else if (statusCode === 500) {
                            const errorMsg = JSON.parse(ctx.xhr.response).message
                            this.showErrorToast("伺服器錯誤 Server error: " + errorMsg)
                        }
                        this.isLoading = false
                    }
                }
            )
        }
    }))
})