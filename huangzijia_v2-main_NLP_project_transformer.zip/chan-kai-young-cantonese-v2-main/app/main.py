from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
load_dotenv()

from route.get_melodies import melody_generator_router
from route.get_lyrics import lyrics_generator_router
from route.get_tones import tones_generator_router
from utils.const import SCALE, RANGE_OPTIONS, OCTAVES
from utils.models import GetMelodiesException, GetTonesException
from config import STATIC_ABS_PATH, templates

app = FastAPI()
app.mount("/static", StaticFiles(directory=STATIC_ABS_PATH), name="static")

frontend_url = r"http://localhost:5173"
origins = [
    frontend_url,
]

# middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
@app.middleware("http")
async def error_handler(request: Request, call_next):
    response = await call_next(request)
    if response.status_code == 404:
        response = templates.TemplateResponse("404.html", {"request": request}, status_code=404)
    return response

# pages
@app.get("/", response_class=HTMLResponse)
def default_layout(request: Request):
    return templates.TemplateResponse("base.html", {"request": request})

@app.get("/melody-generator", response_class=HTMLResponse)
def melody_generator_page(request: Request):
    template_response = templates.TemplateResponse("melody_generator.html", {"request": request, "scale": SCALE, "range_options": RANGE_OPTIONS})
    template_response.headers["HX-Redirect"] = "/melody-generator"
    return template_response

@app.exception_handler(GetMelodiesException)
async def get_melodies_exception_handler(request: Request, exc: GetMelodiesException):
    return JSONResponse(
        status_code=500,
        content={"message": str(exc), "phrase": exc.phrase, "first_pitch": exc.first_pitch, "octave_range": exc.octave_range}
    )

@app.get("/tones-generator", response_class=HTMLResponse)
def tones_generator_page(request: Request):
    template_response = templates.TemplateResponse("tones_generator.html", {"request": request, "scale": SCALE, "octaves": OCTAVES })
    template_response.headers["HX-Redirect"] = "/tones-generator"
    return template_response

@app.exception_handler(GetTonesException)
async def get_tones_exception_handler(request: Request, exc: GetTonesException):
    return JSONResponse(
        status_code=500,
        content={"message": str(exc), "melody_input": exc.melody_input}
    )

# routers
app.include_router(melody_generator_router)
app.include_router(lyrics_generator_router)
app.include_router(tones_generator_router)