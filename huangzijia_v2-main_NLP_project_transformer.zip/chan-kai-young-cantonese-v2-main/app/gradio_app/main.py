import gradio as gr
from transformers import AutoModelForCausalLM, AutoTokenizer
from fastcore.all import *
from accelerate import init_empty_weights, load_checkpoint_and_dispatch
from utils import generate_lyrics

# load model
print("\u27a4 Loading tokenizer...")
base_model_name = "Mobut-songcomposer/Songcomposer-tone-specific"
checkpoint = "pytorch_model.bin.index.json"
tokz = AutoTokenizer.from_pretrained(base_model_name, trust_remote_code=True)

# with init_empty_weights():
model = None
if not Path("Songcomposer-tone-specific").exists():
    print("\u27a4 Loading fine-tuned model from remote...")
    model = AutoModelForCausalLM.from_pretrained(base_model_name, trust_remote_code=True, device_map="auto")
else:
    print("\u27a4 Loading fine-tuned model locally...")
    model = AutoModelForCausalLM.from_pretrained("./Songcomposer-tone-specific", trust_remote_code=True, device_map="auto")
print("\u2713 Done!")

# create the gradio interface
demo = gr.Interface(
    fn=lambda topic, tones: generate_lyrics(tokz, model, topic, tones),
    inputs=[
        gr.Textbox(label="主題 (Topic)", lines=1),
        gr.Textbox(label="聲調 (Tone contours)", lines=1)
    ],
    outputs=[
        gr.Textbox(label="歌詞 - 1 (Generated lyrics - 1)", lines=1),
        gr.Textbox(label="歌詞 - 2 (Generated lyrics - 2)", lines=1),
        gr.Textbox(label="歌詞 - 3 (Generated lyrics - 3)", lines=1)
    ],
    examples = [
        ["內心的孤寂", "113316"],
        ["矛盾和焦慮", "663642"]
    ],
    title="廣東話歌詞生成器 (Cantonese Lyrics Generator) - Demo",
    description="這是一個廣東話歌詞生成器，輸入主題和聲調，即可就已提供聲調生成一段相對應的歌詞。 (This is a Cantonese lyrics generator. Input a topic and tone contours, and it will generate corresponding lyrics based on the provided tone contours.)"
)
demo.launch(share=True)