from pydantic import BaseModel
import inflect
from typing import Optional

class MusicalTupleUnit(BaseModel):
    note: str
    duration: int
    rest: int

    def __str__(self) -> str:
        return f"<{self.note}>,<{self.duration}>,<{self.rest}>"

class CreateLyricsPrompt(BaseModel):
    topic: str
    lines: list[list[MusicalTupleUnit]]

    def combined_lines(self, lyrics: Optional[list[list[str]]]=None) -> str:
        p = inflect.engine()
        all_lines = []
        for ind, line in enumerate(self.lines):
            ordinal_num = p.number_to_words(p.ordinal(ind + 1))
            all_musical_units = None
            if lyrics is not None:
                lyrics_for_the_line = lyrics[ind]
                line_with_character = zip(lyrics_for_the_line, line)
                line_with_character = list(map(lambda x: f"{x[0]},{str(x[1])}", line_with_character))
                all_musical_units = "|".join(line_with_character)
            else:
                all_musical_units = "|".join(map(str, line))
            all_lines.append(f"The {ordinal_num} line:{all_musical_units}")
        return "\n ".join(all_lines)

class SCQuestionAnswer(BaseModel):
    question: CreateLyricsPrompt
    answer: Optional[list[list[str]]] = None

    @property
    def assembled_question(self):
        return f"Create lyrics on topic {self.question.topic} to accompany the given melody. <bom> Total {len(self.question.lines)} lines.{self.question.combined_lines()}\n<eom>"

    @property
    def assembled_answer(self):
        combined_lines = self.question.combined_lines(lyrics=self.answer)
        return f"<bop> Total {len(self.question.lines)} lines. {combined_lines}\n<eop>"

# represent tones 1-6 as MusicalTupleUnits, which contains the respective special tokens
tone_mappings = {
    "1": MusicalTupleUnit(note="A#4", duration=250, rest=250),
    "2": MusicalTupleUnit(note="C4", duration=200, rest=200),
    "3": MusicalTupleUnit(note="G3", duration=175, rest=175),
    "4": MusicalTupleUnit(note="D3", duration=125, rest=125),
    "5": MusicalTupleUnit(note="G#2", duration=100, rest=100),
    "6": MusicalTupleUnit(note="D2", duration=50, rest=50),
}