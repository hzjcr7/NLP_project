#%%
# input: list[int] (tones of the expected lyrics), e.g [1, 2, 3, 4]
# output: str (output from model), e.g "知紙自知"
prompt = "oafutnf1234"

def num_to_spec_token(prompt):
    output = ""
    for i, char in enumerate(prompt):
        if 49<=ord(char) and ord(char)<=54 and i<len(prompt)-1:
            ot = '<|tone_' + char + '|>'
            output += ot + ', '
        elif 49<=ord(char) and ord(char)<=54:
            output += '<|tone_' + char + '|>'
        else:
            output += char
    return output
num_to_spec_token(prompt)
#%%
import back