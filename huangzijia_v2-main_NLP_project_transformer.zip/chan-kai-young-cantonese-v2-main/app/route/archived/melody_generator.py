from typing import Optional, Annotated
from pydantic import BaseModel
from fastapi import APIRouter, Form

from utils import intervals
from utils.convert_digit import convert_digit
from utils.get_tones import get_jyutping, get_tones
from utils.get_contours import get_contours
from utils.assign_pitch import assign_pitch

class MelodyByPhraseReturn(BaseModel):
    phrase: str
    jyutping_phrase: Optional[str] = None
    melodies: list[list[str]] = []

melody_generator_router = APIRouter()

conversion = 0
result_by_ip = {}
print_tones = []
score_list = []
image_list = []
num_list = []

@melody_generator_router.post("/get-melodies")
def get_melodies(
    phrase: Annotated[str, Form()],
    first_pitch: Annotated[str, Form()],
    octave_range: Annotated[str, Form()]
) -> Optional[MelodyByPhraseReturn]:
    try:
        melody_by_phrase = MelodyByPhraseReturn(phrase=phrase)
        jyutping_phrase = get_jyutping(phrase)
        melody_by_phrase.jyutping_phrase = jyutping_phrase
        if jyutping_phrase is None:
            return None
        tones = get_tones(jyutping_phrase)
        pitch = first_pitch
        pitch_value = intervals.scale.index(pitch + "4")  # C4 = 24
        combinations = get_contours(tones)

        for n in range(len(tones)):
            print_tones.append(tones[n] + 1)
            
        output: list[int | str] = []  # int for pitch values, str for arrows
        num_list = []
        melody_list = []
        counter = 0 # number of possibilities
        fault = 0 # check number of unintelligible conditions if more than two characters
            
        # if there are only two characters
        if len(tones) == 2:
            two_char_change = combinations[0]
            for n in range(len(two_char_change)):
                output.append(pitch_value) # append value of first note
                nextpitch = pitch_value + two_char_change[n] # calculate value of next note
                # if the next note is higher, append up arrow
                if two_char_change[n] > 0:
                    output.append('\u2191')
                # if the next note is the same, append right arrow
                if two_char_change[n] == 0:
                    output.append('\u2192')
                # if the next note is lower, append down arrow
                if two_char_change[n] < 0:
                    output.append('\u2193')
                output.append(nextpitch)
                result = assign_pitch(output)
                melody_list.append(result)
                counter += 1
                output.clear()
            melody_key = convert_digit(phrase)
            melody_by_phrase.melodies = melody_list
        
        if len(tones) > 2:
            descend_equal_alt = []
            descend_alt = []
            equal_alt = []
            unequal_alt = [] #equal pitch not allowed for alternating characters
            interval_check = [] #m2 and M3 in either direction not allowed for alternating characters

            for n in range(2, len(tones)):
                # tones 1 - 1 - 1
                if tones[n] == 0 and tones[n - 1] == 0 and tones[n - 2] == 0:
                    descend_equal_alt.append(n)

                # tones 1 - 2 - 1
                if tones[n] == 0 and tones[n - 1] == 1 and tones[n - 2] == 0:
                    descend_equal_alt.append(n)

                # tones 1 - 4 - 3 (only this combination needed) !!! need to check
                if tones[n - 2] == 0 and tones[n - 1] == 3 and tones[n] == 2:
                    descend_alt.append(n)
                    # print("working")

                # tones 2 - 4 - 3 (only this combination needed) !!! need to check
                if tones[n - 2] == 1 and tones[n - 1] == 3 and tones[n] == 2:
                    descend_alt.append(n) # only descending alternating tones allowed

                # tones 4 - ? - 4
                if tones[n] == 3 and tones[n - 2] == 3:
                    equal_alt.append(n) # only equal alternating tones allowed

                # tones 3 - low - 3
                if (tones[n] == 2 and tones[n - 1] == 3 and tones[n - 2] == 2) or (tones[n] == 2 and tones[n - 1] == 5 and tones[n - 2] == 2):
                    equal_alt.append(n) # only equal alternating tones allowed

                # tones 5 - low - 5
                if (tones[n] == 4 and tones[n - 1] == 3 and tones[n - 2] == 4) or (tones[n] == 4 and tones[n - 1] == 5 and tones[n - 2] == 4):
                    equal_alt.append(n) # only equal alternating tones allowed

                # tones 6 - ? - 6  #updated Jan 23 2023
                if tones[n - 2] == 5 and tones[n] == 5:
                    interval_check.append(n) #m2 between alternating tones not allowed)

                # tones 4 - ? - 6 or 6 - ? - 4 Added Aug 2022
                if (tones[n - 2] == 3 and tones[n] == 5) or (tones[n - 2] == 5 and tones[n] == 3):
                    unequal_alt.append(n) #equal alternating tones are not allowed

                # tones 5 - ? - 6  or  3 - ? - 6 Added Aug 2022
                if (tones[n - 2] == 4 and tones[n] == 5) or (tones[n - 2] == 2 and tones[n] == 5):
                    unequal_alt.append(n) #equal alternating tones are not allowed

                # tones 6 - ? - 5  or  6 - ? - 3 Added Aug 2022
                if (tones[n - 2] == 5 and tones[n] == 4) or (tones[n - 2] == 5 and tones[n] == 2):
                    unequal_alt.append(n)

                # tones 5 - ? - 4  or  3 - ? - 4 Added Sep 2022
                if (tones[n - 2] == 4 and tones[n] == 3) or (tones[n - 2] == 2 and tones[n] == 3):
                    unequal_alt.append(n) #equal alternating tones are not allowed

                # tones 4 - ? - 5  or  4 - ? - 3 Added Sep 2022
                if (tones[n - 2] == 3 and tones[n] == 4) or (tones[n - 2] == 3 and tones[n] == 2):
                    unequal_alt.append(n)

                # tones 1 - ? - 3  or  3 - ? - 1 Added Aug 2022
                if (tones[n - 2] == 0 and tones[n] == 2) or (tones[n - 2] == 2 and tones[n] == 0):
                    unequal_alt.append(n)

                # tones 1 - ? - 5  or  5 - ? - 1 Added Aug 2022
                if (tones[n - 2] == 0 and tones[n] == 4) or (tones[n - 2] == 4 and tones[n] == 0):
                    unequal_alt.append(n)

                # print(equal_alt) # for bug check

                # Create initial list of tones
                # Combinations[0] contains possible intervals from character 1 to character 2
            
            # combine initial list (Three tones)
            change: list[list[int]] = [
                [i, j]
                for i in combinations[0]
                    for j in combinations[1]
            ]

            # TODO: confirm if this part is intended or bugged
            # Add values to the list until end of list, if there are more than 2 characters
            for n in range(2, len(combinations)):
                # add further changes to the list (Four or more tones)
                change = [
                    [*initial_tone_list, tone]
                    for initial_tone_list in change
                        for tone in combinations[n]
                ]
                
            for n in range(len(change)):
                num_list.append(pitch_value)
                nextpitch = pitch_value
                for m in range(len(change[n])):
                    nextpitch = nextpitch + change[n][m]
                    num_list.append(nextpitch)

                #transpose the melody up an octave if the highest pitch is between A3 and G#4
                if max(num_list) in range(24, 35):
                    if max(num_list) - min(num_list) > 6:
                        for n in range(len(num_list)):
                            num_list[n] = num_list[n] + 12

                #discard according to melody filter:
                if octave_range != 'no_filter':
                    if max(num_list) - min(num_list) > int(octave_range):
                        num_list.clear()
                        output.clear()
                        continue

                #Add arrows to num_list to create output
                #append first pitch to output
                output.append(num_list[0])
                for n in range(1, len(num_list)):
                    if num_list[n] > num_list[n - 1]:
                        output.append('\u2191') #up arrow
                    if num_list[n] == num_list[n - 1]:
                        output.append('\u2192') #level arrow
                    if num_list[n] < num_list[n - 1]:
                        output.append('\u2193') #down arrow
                    output.append(num_list[n])

                if len(descend_equal_alt) != 0:
                    for n in range(len(descend_equal_alt)):
                        m = descend_equal_alt[n] #2
                        # only descending or equal allowed
                        if output[m*2] > output[(m - 2)*2]:  #如後面的字高於前面的字
                            fault += 1

                if len(descend_alt) != 0:
                    for n in range(len(descend_alt)):
                        m = descend_alt[n] #2
                        # if both pitches are equal or if the 3rd pitch is higher
                        # Output already contains arrows, so if I need the 3rd pitch, I need to find the 6th digit, therefore m*2
                        if output[m*2] >= output[(m - 2)*2]: #2* and -2 because of the arrows #如個第三字高於或等於第一字
                            fault += 1
                        # if the 1st pitch is higher than the 3rd pitch by the following intervals:
                        _intervals = [2, 4, 7, 9, 11]
                        if output[(m - 2)*2] - output[m*2] not in _intervals:
                            fault += 1


                if len(interval_check) != 0:
                    for n in range(len(interval_check)):
                        m = interval_check[n]
                        _intervals = [1, -1, 2, -2, 4, -4, 3, -3]
                        for interval in _intervals:
                            if output[(m - 2)*2] - output[m*2] == interval:
                                fault += 1

                if len(equal_alt) != 0:
                    for n in range(len(equal_alt)):
                        m = equal_alt[n] #2
                        # if the 3rd pitch is lower or higher
                        if output[m*2] != output[(m - 2)*2] : #2* and -2 because of the arrows  ＃如後面的字不等於前面的字
                            fault += 1

                if len(unequal_alt) != 0:
                    for n in range(len(unequal_alt)):
                        m = unequal_alt[n] #2
                        # if the 3rd pitch equals the 1st pitch  ＃如後面的字等於前面的字 added Aug 2022
                        if output[m*2] == output[(m - 2)*2] :
                            fault += 1

                if fault == 0:
                    result = assign_pitch(output)
                        #result_melody = convert_melody(output)
                        #print(result_melody)
                    melody_list.append(result)
                        #score_list.append(result_melody)
                    counter += 1
                        # print(output)
                    # print(counter, ": ", sep ="", end="")
                    # print(*result, sep=" ")

                melody_key = convert_digit(phrase)
                melody_by_phrase.melodies= melody_list
                num_list.clear()
                output.clear()

                #reset fault counter
                fault = 0

                if counter > 9999: #Web only - 限制結果在server capacity之內
                    break
        return melody_by_phrase
    
    except Exception as e:
        print(e)
        raise e