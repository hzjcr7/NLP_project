from pydantic import BaseModel
from typing import Optional, Annotated
from fastapi import APIRouter, Query
from itertools import product

from utils import intervals
from utils.get_tones import get_jyutping


lyrics_generator_router = APIRouter()

class GetLyricsReturn(BaseModel):
    lyrics: str
    jyutping_lyrics: Optional[str] = None

class Succession(BaseModel):
    start: str
    end: str
    
@lyrics_generator_router.get("/lyrics-generator")
def get_lyrics(melody_input: Annotated[list[str], Query()]) -> list[GetLyricsReturn]:
    try:
        print(f"{melody_input=}")
        
        # Find contours from melody (note contours[0] means the contour between the 1st and 2nd pitch)
        contours: list[int] = [intervals.scale.index(melody_input[i]) - intervals.scale.index(melody_input[i - 1]) for i in range(1, len(melody_input))]
        print(f"{contours=}")
        
        # find possible tone successions for each contour
        possible_tone_successions = { ind: list[Succession]() for ind in range(len(contours)) }
        for ind, contour in enumerate(contours):
            for succession, supported_contours in intervals.tone_successions.items():
                if contour in supported_contours:
                    start, end = succession.split("-")
                    possible_tone_successions[ind].append(Succession(start=start, end=end))
        print(f"{possible_tone_successions=}", end="\n\n")
        
        # find possible overall tone combinations
        all_combinations: list[tuple[Succession, ...]] = list(product(*possible_tone_successions.values()))    
        
        # filter out invalid combinations
        valid_combinations = all_combinations
        for i in range(1, len(possible_tone_successions)):
            # perform pairwise checks and update valid_combinations
            valid_combinations = list(filter(lambda x: x[i].start == x[i - 1].end , valid_combinations))
        print(f"{valid_combinations=}", end="\n\n")
        
        def parse_succession_combinations(combination: tuple[Succession, ...]) -> list[str]:
            tail = combination[-1].end
            path = list(map(lambda succession: succession.start, combination))
            return [*path, tail]
        
        possible_tone_combinations = list(map(parse_succession_combinations, valid_combinations))
        print(f"{possible_tone_combinations=}", end="\n\n")
        
        # call GPT to fill in lyrics based on tone combinations
        # completion = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        
        generated_lyrics = "我沒有為你傷春悲秋不配有憾事"
        res = GetLyricsReturn(
            lyrics=generated_lyrics,
            jyutping_lyrics=get_jyutping(generated_lyrics)
        )
        return [res]

    except Exception as e:
        print(e)
        raise e