from typing import Annotated
from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse
from itertools import product

from utils import intervals
from utils.models import Succession, GetTonesReturn, TonesBySystem, GetTonesException
from config import templates

tones_generator_router = APIRouter()

@tones_generator_router.post("/get-tones", response_class=HTMLResponse)
def get_tones(request: Request, melody_input: Annotated[list[str], Form()]):
    try:
        parsed_melody_input = list(map(lambda pitch: pitch.replace("s", "#"), melody_input))
        print(f"{parsed_melody_input=}")
        
        # Find contours from melody (note contours[0] means the contour between the 1st and 2nd pitch)
        contours: list[int] = [intervals.scale.index(parsed_melody_input[i]) - intervals.scale.index(parsed_melody_input[i - 1]) for i in range(1, len(parsed_melody_input))]
        # print(f"{contours=}")
        
        # find possible tone successions for each contour
        possible_tone_successions = { ind: list[Succession]() for ind in range(len(contours)) }
        for ind, contour in enumerate(contours):
            for succession, supported_contours in intervals.tone_successions.items():
                if contour in supported_contours:
                    start, end = succession.split("-")
                    possible_tone_successions[ind].append(Succession(start=start, end=end))
        # print(f"{possible_tone_successions=}", end="\n\n")
        
        # find possible overall tone combinations
        all_combinations: list[tuple[Succession, ...]] = list(product(*possible_tone_successions.values()))    
        
        # filter out invalid combinations
        valid_combinations = all_combinations
        for i in range(1, len(possible_tone_successions)):
            # perform pairwise checks and update valid_combinations
            valid_combinations = list(filter(lambda x: x[i].start == x[i - 1].end , valid_combinations))
        # print(f"{valid_combinations=}", end="\n\n")
        
        def parse_succession_combinations(combination: tuple[Succession, ...]) -> list[str]:
            tail = combination[-1].end
            path = list(map(lambda succession: succession.start, combination))
            return [*path, tail]
        
        possible_tone_combinations = list(map(parse_succession_combinations, valid_combinations))
        # print(f"{possible_tone_combinations=}", end="\n\n")
        
        get_tones_return = GetTonesReturn(combinations=list(map(TonesBySystem.parse_tones, possible_tone_combinations)))
        print(f"Tone combinations (first 5 results):")
        print(*get_tones_return.combinations[:5], sep="\n")
        get_tones_return = get_tones_return.model_dump(mode="json")
        response = {
            "request": request,
            **get_tones_return
        }
        return templates.TemplateResponse(
            "generated_tones.html",
            response
        )
    
    except Exception as e:
        print(e)
        raise GetTonesException(message=str(e), melody_input=melody_input)
