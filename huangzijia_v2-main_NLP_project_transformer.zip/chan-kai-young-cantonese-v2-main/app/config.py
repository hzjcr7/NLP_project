import os
from fastapi.templating import Jinja2Templates

APP_PATH = os.path.dirname(__file__)
STATIC_ABS_PATH = os.path.join(APP_PATH, "static")
TEMPLATE_ABS_PATH = os.path.join(APP_PATH, "templates")
templates = Jinja2Templates(directory=TEMPLATE_ABS_PATH)