#Version 2021-09-09
#the range has to be 5 octaves so that the results can be mapped to a correct picture

scale = ['C2','C#2','D2','D#2','E2','F2','F#2','G2','G#2','A2','A#2','B2',
         'C3','C#3','D3','D#3','E3','F3','F#3','G3','G#3','A3','A#3','B3',
         'C4','C#4','D4','D#4','E4','F4','F#4','G4','G#4','A4','A#4','B4',
         'C5','C#5','D5','D#5','E5','F5','F#5','G5','G#5','A5','A#5','B5',
         'C6','C#6','D6','D#6','E6','F6','F#6','G6','G#6','A6','A#6','B6']

flats = ['C2','Db2','D2','Eb2','E2','F2','Gb2','G2','Ab2','A2','Bb2','B2',
         'C3','Db3','D3','Eb3','E3','F3','Gb3','G3','Ab3','A3','Bb3','B3',
         'C4','Db4','D4','Eb4','E4','F4','Gb4','G4','Ab4','A4','Bb4','B4',
         'C5','Db5','D5','Eb5','E5','F5','Gb5','G5','Ab5','A5','Bb5','B5',
         'C6','Db6','D6','Eb6','E6','F6','Gb6','G6','Ab6','A6','Bb6','B6']

starting = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']

# when NOT to use #?
Cs = [1, 13, 25, 37]
Ds = [3, 15, 27, 39]
Fs = [6, 18, 30, 42]
Gs = [8, 20, 32, 44]
As = [10, 22, 34, 46]

condition_Cs = ['C','Db','Eb','F','Gb','Ab','Bb']
condition_Ds = ['C','Db','D','Eb','F','Gb','G','Ab','A','Bb']
condition_Fs = ['Db','Eb','F','Gb','Ab','Bb']
condition_Gs = ['C','Db','Eb','F','Gb','G','Ab','Bb']
condition_As = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B']

# check whether flats are converted to sharps in the input

# Tone 1 successions
i_i = [0] #tone 1 to tone 1
i_ii = [0, -1, -2, -3, -5] #tone 1 to tone 2 #added -1, -5 in 2021
i_iii = [-2, -4] #tone 1 to tone 3 [-6 is conditional]
i_iv = [-7, -8, -9, -10, -11, -12, -14] # [-5 is conditional － removed Dec 2021 ]
i_v = [-2, -4, -5, -7, -9, -11] #added -5, -6, -7, -9, -11 in 2021 #removed -6 2021-12
i_vi = [-3, -5, -7, -8, -10]  #[-7 is conditional] #added 6, 7, 10 12, in 2021 #6, 12 removed in office - need to check

# Tone 2 successions
ii_i = [0, 2, -2] #tone 2 to tone 1 #added -2 for demo in 2023
ii_ii = [0, -2, -3] #tone 2 to tone 2  #added －2, －3 in 2021
ii_iii = [-2, -4, -6] #tone 2 to tone 3  #added -7, -9, -11 in 2021  #-6, -7, -9, -11 removed - need to check [-6 is conditional]
ii_iv = [-5, -7, -8, -9, -10, -11, -12, -14] # [-5 is conditional]
ii_v = [-2, -3, -4, -6, -7, -9, -11] #added -3, -9, -11 in 2021
ii_vi = [-3, -5, -7, -8, -10] #added -6, -10 in 2021  #-6 removed in office - need to check

# Tone 3 successions
iii_i = [2, 4] #6 removed since 2021
iii_ii = [2, 4, 6] #tone 3 to tone 2  #6 is conditional
iii_iii = [0]
iii_iv = [-3, -5, -7, -8, -10] # [-3, -7 = conditional]
iii_v = [0]
iii_vi = [-1, -3] #added -6 in 2021, but removed in office

# Tone 4 successions
iv_i = [7, 8, 9, 10, 11, 12, 14]  # [5 is conditional － removed Dec 2021 ] # M9 excluded #14 added in 2021
iv_ii = [7, 8, 9, 10, 11, 12, 14]    # M9 excluded #14 added in 2021
iv_iii = [3, 5, 7, 8, 10, 13] #[3, 7 is conditional] #d5, 13 added in 2021 #9, 12 removed in office, need to check
iv_iv = [0]
iv_v = [3, 5, 7, 8, 10, 12] #[3, 7 = conditional] # removed 6, 9 in Dec 2021
iv_vi = [2, 4]

# Tone 5 successions
v_i = [2, 4, 7, 9] #P5, M6 added in 2021
v_ii = [2, 4, 6]
v_iii = [0]
v_iv = [-3, -5, -7, -8, -10] #[-3, -7 = conditional] #-4 added in 2021; removed in Dec
v_v = [0]
v_vi = [-1, -3] #-6 (ti fa), -8 added in 2021; removed in Dec 2021

# Tone 6 successions
vi_i = [3, 5, 7, 8, 10] #[7, 10, 12 is conditional] #10 added in office, need to check   #4 removed, need to [fix]
vi_ii = [3, 5, 7, 8, 10] #10 added in office, need to check/fix
vi_iii = [1, 3]
vi_iv = [-2, -4]
vi_v = [1, 3]
vi_vi = [0]

# aggregate all successions into a dictionary
tone_successions = {
    "1-1": i_i,
    "1-2": i_ii,
    "1-3": i_iii,
    "1-4": i_iv,
    "1-5": i_v,
    "1-6": i_vi,
    
    "2-1": ii_i,
    "2-2": ii_ii,
    "2-3": ii_iii,
    "2-4": ii_iv,
    "2-5": ii_v,
    "2-6": ii_vi,
    
    "3-1": iii_i,
    "3-2": iii_ii,
    "3-3": iii_iii,
    "3-4": iii_iv,
    "3-5": iii_v,
    "3-6": iii_vi,
    
    "4-1": iv_i,
    "4-2": iv_ii,
    "4-3": iv_iii,
    "4-4": iv_iv,
    "4-5": iv_v,
    "4-6": iv_vi,
    
    "5-1": v_i,
    "5-2": v_ii,
    "5-3": v_iii,
    "5-4": v_iv,
    "5-5": v_v,
    "5-6": v_vi,
    
    "6-1": vi_i,
    "6-2": vi_ii,
    "6-3": vi_iii,
    "6-4": vi_iv,
    "6-5": vi_v,
    "6-6": vi_vi,
}

contour = [[i_i, i_ii, i_iii, i_iv, i_v, i_vi],
           [ii_i, ii_ii, ii_iii, ii_iv, ii_v, ii_vi],
           [iii_i, iii_ii, iii_iii, iii_iv, iii_v, iii_vi],
           [iv_i, iv_ii, iv_iii, iv_iv, iv_v, iv_vi],
           [v_i, v_ii, v_iii, v_iv, v_v, v_vi],
           [vi_i, vi_ii, vi_iii, vi_iv, vi_v, vi_vi]]