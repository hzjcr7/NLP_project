from utils import intervals

def assign_pitch(output: list[int | str]) -> list[str]:
    pset: list[str] = []
    if type(output[0]) is not int:
        raise TypeError(f"Expected first element in output to be a pitch value. Got {output[0]} ({type(output[0])})")
    pset.append(intervals.scale[output[0]])  # append the first pitch

    for ind, ele in enumerate(output[1:]):
        # if str(output[i]).lstrip('-').isdigit() == True:
        if type(ele) is int:
            # correct accidentals:
            enharm = 0
            pitch_check = "".join(filter(lambda x: not x.isdigit(), pset[ind - 1]))

            # correct C-sharp:
            if ele in intervals.Cs and pitch_check in intervals.condition_Cs:
                pset.append(intervals.flats[ele])
                enharm += 1
            if ele in intervals.Ds and pitch_check in intervals.condition_Ds:
                pset.append(intervals.flats[ele])
                enharm += 1
            if ele in intervals.Fs and pitch_check in intervals.condition_Fs:
                pset.append(intervals.flats[ele])
                enharm += 1
            if ele in intervals.Gs and pitch_check in intervals.condition_Gs:
                pset.append(intervals.flats[ele])
                enharm += 1
            if ele in intervals.As and pitch_check in intervals.condition_As:
                pset.append(intervals.flats[ele])
                enharm += 1

            # if no accidentals corrections are needed
            if enharm == 0:
               pset.append(intervals.scale[ele])
        
        elif type(ele) is str:
            pset.append(ele) # append the arrow
    return pset