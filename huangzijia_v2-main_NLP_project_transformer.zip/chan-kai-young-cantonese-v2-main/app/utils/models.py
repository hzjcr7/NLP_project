from pydantic import BaseModel
from typing import Optional

# get melodies
class Melody(BaseModel):
    melody: list[str]
    melody_without_arrows: list[str]
    rendered_melody: list[str]

class MelodyByPhraseReturn(BaseModel):
    phrase: str
    jyutping_phrase: Optional[str] = None
    melodies: list[Melody] = []

class GetMelodiesException(Exception):
    def __init__(self, message: str, phrase: Optional[str], first_pitch: Optional[str], octave_range: Optional[str]):
        super().__init__(message)
        self.phrase = phrase
        self.first_pitch = first_pitch
        self.octave_range = octave_range

# get tones & lyrics
class Succession(BaseModel):
    start: str
    end: str

class TonesBySystem(BaseModel):
    six_tones: list[str]
    tones_0243: list[str]
    tones_394052: list[str]

    @classmethod
    def parse_tones(self, tones: list[str]):
        map_0243 = {
            "1": "3",
            "2": "3",
            "3": "4",
            "4": "0",
            "5": "4",
            "6": "2"
        }
        map_394052 = {f"{ind + 1}": v for ind, v in enumerate([*"394052"])}
        return self(
            six_tones=tones,
            tones_0243=list(map(lambda tone: map_0243[tone], tones)),
            tones_394052=list(map(lambda tone: map_394052[tone], tones)),
        )

class GetTonesReturn(BaseModel):
    combinations: list[TonesBySystem]

class GetTonesException(Exception):
    def __init__(self, message: str, melody_input: Optional[list[str]]):
        super().__init__(message)
        self.melody_input = melody_input

class GetLyricsReturn(BaseModel):
    lyrics: str
    jyutping_lyrics: Optional[str] = None