SCALE = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
OCTAVES = [
    {
        "label": "八度 2 Octave 2",
        "value": "2",
    },
    {
        "label": "八度 3 Octave 3",
        "value": "3",
    },
    {
        "label": "八度 4 Octave 4",
        "value": "4",
    },
    {
        "label": "八度 5 Octave 5",
        "value": "5",
    },
    {
        "label": "八度 6 Octave 6",
        "value": "6",
    },
]
RANGE_OPTIONS = [
    {
        "label": "音域不限 Unlimited Range",
        "value": "no_filter"
    },
    {
        "label": "≤八度⠀⠀⠀⠀⠀≤ octave",
        "value": "12"
    },
    {
        "label": "≤八度加五度⠀≤ octave + 5th",
        "value": "19"
    },
    {
        "label": "≤兩個八度⠀⠀≤ 2 octaves",
        "value": "24"
    },
]
IMAGE_FOLDER = "/static/pitch_images/"