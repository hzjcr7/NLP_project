from typing import Optional
from utils.convert_digit import convert_digit
from pyjyutping import jyutping

def get_jyutping(phrase: Optional[str]) -> Optional[str]:
    if phrase is None:
        return None
    converted_phrase = convert_digit(phrase)
    jyutping_phrase = jyutping.convert(converted_phrase)
    return jyutping_phrase

# Get a phrase and its tones:
def get_tones(jyutping_phrase: str) -> list[int]:
    word = jyutping_phrase.split()
    
    # -1 for the tone number to serve as index in get_contours
    tone_numbers: list[int] = list(map(lambda jyutping: int(jyutping[-1]) - 1, word))
    return tone_numbers