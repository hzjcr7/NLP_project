from utils import intervals

def get_contours(tones: list[int]) -> list[list[int]]:
    combine : list[list[int]] = []
    for n in range(1, len(tones)):
        combine.append(intervals.contour[tones[n - 1]][tones[n]])
    return combine