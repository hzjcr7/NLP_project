# Convert a phrase's digit to text (replace 394052786 with equivalent Chinese)
def convert_digit(phrase: str) -> str:
    numeric_to_chin = {
        "0": "零",
        "1": "一",
        "2": "二",
        "3": "三",
        "4": "四",
        "5": "五",
        "6": "六",
        "7": "七",
        "8": "八",
        "9": "九"
    }
    converted_phrase = "".join(map(lambda word: numeric_to_chin[word] if word in numeric_to_chin else word, list(phrase)))
    return converted_phrase