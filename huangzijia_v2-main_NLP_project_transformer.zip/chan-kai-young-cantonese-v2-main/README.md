# chan-kai-young-cantonese-v2

[/frontend] yarn dev
[/backend] uvicorn main:app --reload